# MIPS_Assembler
Exemplo de um Assembler de arquitetura MIPS.



Comando para utilizar o exemplo:

**python simple_mips_assembler.py -mif assembly.asm > assembly.mif**