# MIPS_Assembler
Exemplo de um Assembler de arquitetura MIPS.
